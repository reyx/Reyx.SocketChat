using System.Web;
using XSockets.Core.Common.Socket;

[assembly: PreApplicationStartMethod(typeof($rootnamespace$.$safeitemrootname$), "Start")]

namespace $rootnamespace$
{
    public static class $safeitemrootname$
    {
        private static IXSocketServerContainer wss;
        public static void Start()
        {
            wss = XSockets.Plugin.Framework.Composable.GetExport<IXSocketServerContainer>();
            wss.StartServers();
        }        
    }
}
